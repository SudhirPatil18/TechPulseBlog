<?php
session_start();
define("ROOT_URL", "http://localhost/blog/");
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'blog');

