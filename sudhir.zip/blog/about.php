<?php 
include 'partials/header.php'
?>


<section class="empty__page">
    <h3>We are committed to authenticity, accuracy, and relevance in all our content. Our team of Ayurvedic experts and passionate writers work diligently to provide well-researched and practical information that you can trust.</h3>
</section>

<?php
include './partials/footer.php';
?>