
<footer>
    <div class="footer__socials">
        <a href="https://healthtipskannada.com/" target="_blank"><i class="uil uil-youtube"></i></a>
        <a href="https://www.instagram.com/Health Tips Kannada/" target="_blank"><i class="uil uil-instagram-alt"></i></a>
        <a href="https://api.whatsapp.com/send?text=Bevina%20Soppu%20Uses%20%7C%202%20Super%20%E0%B2%AC%E0%B3%87%E0%B2%B5%E0%B2%BF%E0%B2%A8%20%E0%B2%B8%E0%B3%8A%E0%B2%AA%E0%B3%8D%E0%B2%AA%E0%B2%BF%E0%B2%A8%20%E0%B2%B2%E0%B2%BE%E0%B2%AD%E0%B2%97%E0%B2%B3%E0%B3%81" target="_blank"><i class="uil uil-whatsapp"></i></a> 
        <a href="https://www.facebook.com/login.php?skip_api_login=1&api_key=966242223397117&signed_next=1&next=https%3A%2F%2Fwww.facebook.com%2Fsharer%2Fsharer.php%3Fu%3Dhttps%253A%252F%252Fhealthtipskannada.com%252Fabout-us%252F&cancel_url=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Fclose_window%2F%3Fapp_id%3D966242223397117%26connect%3D0%23_%3D_&display=popup&locale=en_GB" target="_blank"><i class="uil uil-facebook-f"></i></a> 
    </div>
    <div class="container footer__container">
        <article>
            <h4>Categotries</h4>
            <ul>
                <li><a href="">Eye</a></li>
                <li><a href="">Hair</a></li>
                <li><a href="">Beauty</a></li>
                <li><a href="">Skin</a></li>
                <li><a href="">General Disease</a></li>
            
            </ul>
        </article>
        <article>
            <h4>Support</h4>
            <ul>
                <li><a href="">Online Support</a></li>
                <li><a href="">Call Numbers</a></li>
                <li><a href="">Emails</a></li>
            </ul>
        </article>

        <article>
            <h4>Blog</h4>
            <ul>
                <li><a href="">Recent</a></li>
                <li><a href="">Popular</a></li>
                <li><a href="">Categories</a></li>
            </ul>
        </article>

        <article>
            <h4>PermaLinks</h4>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact.php">Contact</a></li>
                
            </ul>
        </article>
    </div>

    <div class="footer__copyright">
        <small>Copyright &copy; HEALTH TIPS KANNADA</small>
    </div>
  </footer>



  <script src="<?= ROOT_URL ?>js/main.js"></script>
</body>
</php>


